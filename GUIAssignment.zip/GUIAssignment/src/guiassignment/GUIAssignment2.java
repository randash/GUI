
package guiassignment;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

public class GUIAssignment2 extends JFrame{
    private JPanel keysPanel;
    private JButton[] keysButtons;
    private JTextField textFieldL;

    public GUIAssignment2(String title){
        super(title);
        textFieldL = new JTextField("LCD");
        textFieldL.setFont(new Font("Arial", Font.BOLD, 20));
        textFieldL.setForeground(Color.blue);
        //textFieldL.setSize(50,50);
        setLayout(new BorderLayout());
        this.add(textFieldL,BorderLayout.NORTH);
        
         keysPanel = new JPanel(new GridLayout(4, 4,3,3));
         keysPanel.setSize(280,260);
         keysButtons = new JButton[16];
         String myArray[]={"0",".","=","+","1","2","3","-","4","5","6","*","7","8","9","/"};
         int length=myArray.length;
         String myArray2[]={"7","8","9","/","4","5","6","*","1","2","3","-","0",".","=","+"};
         for(int i=0;i<16;i++){
             keysButtons[i] = new JButton(myArray2[i]);
             keysPanel.add(keysButtons[i]);
             
         }
         
          add(keysPanel,BorderLayout.CENTER);
        
    }
    
    public static void main(String[] args) {
        //2
        GUIAssignment2 loginFrame2 = new GUIAssignment2("Calculator");
        loginFrame2.setSize(300,280);
        loginFrame2.setResizable(true);
        loginFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame2.setLocationRelativeTo(null);
        loginFrame2.setVisible(true);
    }
    
}
