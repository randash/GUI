package guiassignment;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;

public class GUIAssignment3 extends JFrame {

    private JLabel printer;
    private JTextField textFieldX, textFieldY;
    private JButton buttonOK, buttonCancel;
    private JPanel panelLogin;
    private JTextArea textArea1, textArea2;
    private JScrollPane scrollPane;
    private JCheckBox checkBox, checkBox2, checkBox3;
    private JButton buttonhelp;
    private JPanel keysPanel;
    private final JTextArea textArea3;
    private JRadioButton radio , radio2 , radio3;
    private final JButton buttonset;
    private final JCheckBox checkBox4;

    public GUIAssignment3(String title) {
        super(title);
        this.setLayout(null);

        JLabel printer = new JLabel("Printer:MyPrinter");
        printer.setBounds(40,13, 200, 30);
        textArea1 = new JTextArea();
        textArea1.setBounds(37,40,55 ,60 ); 
        ButtonGroup pg=new ButtonGroup();
       pg.add(checkBox);
       pg.add(checkBox2);
       pg.add(checkBox3);
      
        checkBox = new JCheckBox("Image");
        checkBox2 = new JCheckBox("Text");
        checkBox3 = new JCheckBox("Code");
        
        checkBox.setBounds(95,40, 60, 20);
        checkBox2.setBounds(95,60, 60, 20);
        checkBox3.setBounds(95,80, 60, 20);
        
        textArea2 = new JTextArea();
        textArea2.setBounds(160,40,40,60);
        
        radio=new JRadioButton("Selection");
        radio2=new JRadioButton("All");
        radio3=new JRadioButton("Applet");
        
        radio.setBounds(200,40, 80, 20);
        radio2.setBounds(200,60, 80, 20);
        radio3.setBounds(200,80, 80, 20);
        
        textArea3 = new JTextArea(3, 2);
       textArea3.setBounds(280,40,55 ,60 );
       
        buttonOK=new JButton("OK");
        buttonCancel=new JButton("Cancel");
        buttonset = new JButton("Setup..");
        buttonhelp = new JButton("Help");
        
        buttonOK.setBounds(350, 5, 75, 25);
        buttonCancel.setBounds(350, 40, 75, 25);
        buttonset.setBounds(350, 75, 75, 25);
        buttonhelp.setBounds(350, 110, 75, 25);
        
        JLabel printQuality = new JLabel("Print Quality:  ");
        
        printQuality.setBounds(45,100, 120, 30);
        
        JComboBox Level = new JComboBox();
        Level.setEditable(true);
        Level.addItem("High");
        Level.addItem("Low");
        
        Level.setBounds(155,105, 60, 25);
        
        checkBox4 = new JCheckBox("Print to File");
        
        checkBox4.setBounds(230,105, 100, 25);

        this.add(printer);

        this.add(textArea1);
        this.add(textArea2);
        this.add(textArea3);
        
  
        this.add(checkBox);
        this.add(checkBox2);
        this.add(checkBox3);
        
        this.add(radio);
        this.add(radio2);
        this.add(radio3);
        
        this.add(buttonOK);
        this.add(buttonCancel);
        this.add(buttonset);
        this.add(buttonhelp);
        
        this.add(printQuality);
        this.add(Level);
        
        this.add(checkBox4);

    }

    public static void main(String[] args) {
        GUIAssignment3 loginFrame = new GUIAssignment3("Printer");
        loginFrame.setSize(460, 190);
        loginFrame.setResizable(true);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setVisible(true);
    }

}
