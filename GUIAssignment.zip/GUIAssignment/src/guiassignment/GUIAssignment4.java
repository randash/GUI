package guiassignment;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JRadioButton;
import javax.swing.ListSelectionModel;

public class GUIAssignment4 extends JFrame {

    private JLabel printer;
    private JTextField textFieldX, textFieldY;
    private JButton buttonOK, buttonCancel;
    private JPanel panelLogin;
    private JTextArea textArea1, textArea2;
    private JScrollPane scrollPane;
    private JCheckBox checkBox, checkBox2, checkBox3;
    private JButton buttonhelp;
    private JPanel keysPanel;
    private JTextArea textArea3;
    private JRadioButton radio, radio2, radio3;
    private JButton buttonset;
    private JCheckBox checkBox4;

    public GUIAssignment4(String title) throws HeadlessException {
        super(title);
       // this.setLayout(null);
     panelLogin = new JPanel(new FlowLayout(FlowLayout.CENTER));
        String[] list = {"White", "Black", "Red", "Green",
            "Blue","Cyan","Gray", "White", "Black", "Red", "Green",
            "Blue","Cyan","Gray"};
        JList<String> jl = new JList<>(list);
        jl.setSelectedIndex(1);
        jl.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        jl.setVisibleRowCount(5);
        jl.setLayoutOrientation(JList.VERTICAL);
        //add(new JScrollPane(jl));

       // jl.setBounds(15,5, 100, 90);
        scrollPane = new JScrollPane(jl);
        scrollPane.setPreferredSize(new Dimension(100, 100));
        JButton buttonOK = new JButton("Copy>>>");
        textArea1 = new JTextArea(5,8);
        
       setLayout(new FlowLayout(FlowLayout.CENTER));
        
         panelLogin.add(buttonOK);
         panelLogin.add(textArea1);
         add(scrollPane);
         add(panelLogin);
      
    }

    public static void main(String[] args) {
        GUIAssignment4 loginFrame = new GUIAssignment4("Multiple Selection Lists");
        loginFrame.setSize(400, 190);
        loginFrame.setResizable(true);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setVisible(true);
    }

}
