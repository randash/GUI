
package guiassignment;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;


public class GUIAssignment extends JFrame {
    
private JLabel labelX, labelY;
    private JTextField textFieldX,textFieldY;
    private JButton buttonOK, buttonCancel;
    private JPanel panelLogin;
    private JTextArea textArea;
    private JScrollPane scrollPane;
    private JCheckBox checkBox ,checkBox2;
    JButton buttonhelp ;
    private final JPanel keysPanel;
    private final JPanel secandPanel;
    private final JPanel thirdPanel;

    public GUIAssignment(String title){
        super(title);
        panelLogin = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelLogin.setPreferredSize(new Dimension(360,130));
        panelLogin.setBorder(BorderFactory.createTitledBorder(""));
        keysPanel = new JPanel(new GridLayout(2, 4));
        
        //keysPanel.setBackground(Color.red);
        secandPanel = new JPanel(new GridLayout(2, 2));
        //secandPanel.setBackground(Color.BLACK);
        thirdPanel = new JPanel(new GridLayout(3,1,1,1));
        thirdPanel.setSize(200,100);
        ButtonGroup pg=new ButtonGroup();
        checkBox=new JCheckBox("Snap to Grid");
        checkBox2=new JCheckBox("Show Grid");
        pg.add(checkBox);
        pg.add(checkBox2);
        panelLogin.add(checkBox);
        panelLogin.add(checkBox2);
        keysPanel.add(checkBox);
        keysPanel.add(checkBox2);
        panelLogin.add(keysPanel);
        labelX = new JLabel("x:");
        panelLogin.add(labelX);
        textFieldX = new JTextField("8", 3);
        panelLogin.add(textFieldX);
        labelY = new JLabel("y:");
        panelLogin.add(labelY);
        textFieldY = new JTextField("8", 3);
        panelLogin.add(textFieldY);
        
        secandPanel.add(labelX);
        secandPanel.add(textFieldX);
        secandPanel.add(labelY);
        secandPanel.add(textFieldY);
        
        panelLogin.add(secandPanel);
        
        buttonOK=new JButton("OK");
        buttonCancel=new JButton("CANCEL");
        buttonhelp = new JButton("Help");
        
//        panelLogin.add(buttonOK);
//        panelLogin.add(buttonCancel);    
//        panelLogin.add(buttonhelp);
        
        thirdPanel.add(buttonOK);
        thirdPanel.add(buttonCancel);
        thirdPanel.add(buttonhelp);
        
        panelLogin.add(thirdPanel);
        
        
        add(panelLogin);
        setLayout(new FlowLayout(FlowLayout.CENTER));
    }
    
    public static void main(String[] args) {
        //1
      GUIAssignment loginFrame = new GUIAssignment("Align");        
        loginFrame.setSize(370, 180);
        loginFrame.setResizable(true);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setVisible(true);  

    }
    
}
